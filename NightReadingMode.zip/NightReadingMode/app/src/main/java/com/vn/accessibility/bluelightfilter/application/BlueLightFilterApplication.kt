package com.vn.accessibility.bluelightfilter.application

import android.app.Application
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.os.Build
import android.preference.PreferenceManager
import android.util.Log
import com.google.android.gms.analytics.GoogleAnalytics
import com.google.android.gms.analytics.Tracker
import com.vn.accessibility.bluelightfilter.R
import com.vn.accessibility.bluelightfilter.receiver.BlueLightFilterReceiver
import com.vn.accessibility.bluelightfilter.service.ScreenFilterService
import com.vn.accessibility.bluelightfilter.utils.Utils
import com.vn.accessibility.bluelightfilter.R.xml.global_tracker



/**
 * Created by sev_user on 6/7/2017.
 */
class BlueLightFilterApplication: Application(), SharedPreferences.OnSharedPreferenceChangeListener{

    private val mSharedPrefs: SharedPreferences
        get() = PreferenceManager.getDefaultSharedPreferences(this)

    private val mReceiver = BlueLightFilterReceiver()

    private lateinit var sAnalytics: GoogleAnalytics

    private var sTracker: Tracker ?= null

    override fun onCreate() {
        Log.e("vinh", "BlueLightFilterApplication onCreate")
        context = this
        super.onCreate()
        mSharedPrefs.registerOnSharedPreferenceChangeListener(this)
        var intentFilter = IntentFilter()
        intentFilter.addAction("com.vn.accessibility.bluelightfilter.START_SCHEDULE")
        intentFilter.addAction("com.vn.accessibility.bluelightfilter.END_SCHEDULE")
        intentFilter.addAction("com.vn.accessibility.bluelightfilter.START_FILTER")
        intentFilter.addAction("com.vn.accessibility.bluelightfilter.END_FILTER")
        intentFilter.addAction("android.intent.action.SCREEN_OFF")
        intentFilter.addAction("android.intent.action.SCREEN_ON")
        registerReceiver(mReceiver, intentFilter)

        val intent = Intent(this, ScreenFilterService::class.java) as Intent
        if (mSharedPrefs.getBoolean(Utils.KEY_STATE_OF_FILTER_PREF, false)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        } else {
            //stopService(intent)
        }
        sAnalytics = GoogleAnalytics.getInstance(this)
    }

    /**
     * Gets the default [Tracker] for this [Application].
     * @return tracker
     */
    @Synchronized
    fun getDefaultTracker(): Tracker? {
        // To enable debug logging use: adb shell setprop log.tag.GAv4 DEBUG
        if (sTracker == null) {
            sTracker = sAnalytics.newTracker(R.xml.global_tracker)
        }

        return sTracker
    }

    override fun onTerminate() {
        mSharedPrefs.unregisterOnSharedPreferenceChangeListener(this)
        unregisterReceiver(mReceiver)
        super.onTerminate()
    }

    /**
     * Called when a shared preference is changed, added, or removed. This
     * may be called even if a preference is set to its existing value.

     *
     * This callback will be run on your main thread.

     * @param sharedPreferences The [SharedPreferences] that received
     * *            the change.
     * *
     * @param key The key of the preference that was changed, added, or
     * *            removed.
     */
    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        //TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    companion object {
        lateinit var context: BlueLightFilterApplication
    }

}
