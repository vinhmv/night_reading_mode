package com.vn.accessibility.bluelightfilter.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.preference.PreferenceManager
import com.vn.accessibility.bluelightfilter.application.BlueLightFilterApplication
import com.vn.accessibility.bluelightfilter.service.ScreenFilterService
import com.vn.accessibility.bluelightfilter.utils.Utils

/**
 * Created by sev_user on 6/27/2017.
 */
class StopServiceReceiver : BroadcastReceiver() {

    private val mSharedPrefs: SharedPreferences
        get() = PreferenceManager.getDefaultSharedPreferences(BlueLightFilterApplication.context)

    override fun onReceive(context: Context?, intent: Intent?) {
        //TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
        var intent = Intent(context, ScreenFilterService::class.java)
        context?.stopService(intent)
        var editor = mSharedPrefs.edit()
        editor.putBoolean(Utils.KEY_STATE_OF_FILTER_PREF, false)
        editor.apply()
    }
}