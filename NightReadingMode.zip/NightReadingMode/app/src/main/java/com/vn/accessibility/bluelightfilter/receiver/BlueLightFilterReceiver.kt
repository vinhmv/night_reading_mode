package com.vn.accessibility.bluelightfilter.receiver

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.preference.PreferenceManager
import android.util.Log
import com.vn.accessibility.bluelightfilter.application.BlueLightFilterApplication
import com.vn.accessibility.bluelightfilter.service.ScreenFilterService
import com.vn.accessibility.bluelightfilter.utils.Utils
import java.util.*

/**
 * Created by sev_user on 6/26/2017.
 */
class BlueLightFilterReceiver : BroadcastReceiver (){
    private val mSharedPrefs: SharedPreferences
        get() = PreferenceManager.getDefaultSharedPreferences(BlueLightFilterApplication.context)

    val mIntentService : Intent
            get()= Intent(BlueLightFilterApplication.context, ScreenFilterService::class.java)

    val mIntentBroadcast : Intent
        get()= Intent(BlueLightFilterApplication.context, StopServiceReceiver::class.java)

    private val mAlarmManager: AlarmManager
        get() = BlueLightFilterApplication.context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    override fun onReceive(context: Context?, intent: Intent?) {
        //TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
        var action = intent?.action
        Log.e("vinh", "action : " + action)
        if (action.equals("android.intent.action.SCREEN_OFF")) {
            startFilterBySchedule()
            endFilterBySchedule()
            if (mSharedPrefs.getBoolean(Utils.KEY_STATE_OF_FILTER_PREF, false)) {
                //if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                //    val intent = Intent(context, ScreenFilterService::class.java) as Intent
                //    context?.startForegroundService(intent)
                //} else {
                //    context?.startService(intent)
                //}
            } else {
                context?.stopService(mIntentService)
            }
        } else if (action.equals("com.vn.accessibility.bluelightfilter.START_SCHEDULE")){
            var mIntentService = Intent(context, ScreenFilterService::class.java)
            val pendingIntent = PendingIntent.getService(context, 0, mIntentService, PendingIntent.FLAG_CANCEL_CURRENT)
            //if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                mAlarmManager.setInexactRepeating(AlarmManager.RTC_WAKEUP, getTimeCalendar(Utils.timeStart).timeInMillis,
                        1000*60/2, pendingIntent)
            //} else {
            //    mAlarmManager.set(AlarmManager.RTC, getTimeCalendar(Utils.timeStart).timeInMillis, pendingIntent)
            //}
        } else if (action.equals("com.vn.accessibility.bluelightfilter.END_SCHEDULE")){
            //val pendingIntent = PendingIntent.getBroadcast(BlueLightFilterApplication.context, System.currentTimeMillis().toInt()
            //                                     , mIntentBroadcast, PendingIntent.FLAG_UPDATE_CURRENT)
            var mIntentBroadcast = Intent(context, StopServiceReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(context, 0, mIntentBroadcast, PendingIntent.FLAG_CANCEL_CURRENT)
            Log.e("vinh", "getTimeCalendar(Utils.timeEnd).timeInMillis : " + getTimeCalendar(Utils.timeEnd).timeInMillis)
            //if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                mAlarmManager.setInexactRepeating(AlarmManager.RTC_WAKEUP, getTimeCalendar(Utils.timeEnd).timeInMillis,
                        1000*60/2, pendingIntent)
            //} else {
            //    mAlarmManager.set(AlarmManager.RTC, getTimeCalendar(Utils.timeEnd).timeInMillis, pendingIntent)
            //}
        }
    }

    fun startFilterBySchedule(){
        if (mSharedPrefs.getBoolean(Utils.KEY_ENABLED_SCHEDULE_PREF, false)){
            //Log.e("vinh", "currentTime : " + getCurrentTime())
            //Log.e("vinh", "start time : " + getTimeCalendar(Utils.timeStart))
            if (getCurrentTime().after(getTimeCalendar(Utils.timeStart))){
                Log.e("vinh", "start")
                var editor = mSharedPrefs.edit()
                editor.putBoolean(Utils.KEY_STATE_OF_FILTER_PREF, true)
                editor.apply()
            } else {
                Log.e("vinh", "not start")
                var editor = mSharedPrefs.edit()
                editor.putBoolean(Utils.KEY_STATE_OF_FILTER_PREF, false)
                editor.apply()
            }
        }

    }

    fun endFilterBySchedule(){
        if (mSharedPrefs.getBoolean(Utils.KEY_ENABLED_SCHEDULE_PREF, false)){
            //Log.e("vinh", "currentTime : " + getCurrentTime())
            //Log.e("vinh", "end time : " + getTimeCalendar(Utils.timeEnd))
            if (getCurrentTime().after(getTimeCalendar(Utils.timeEnd))){
                Log.e("vinh", "end")
                var editor = mSharedPrefs.edit()
                editor.putBoolean(Utils.KEY_STATE_OF_FILTER_PREF, false)
                editor.apply()
            }
        }

    }

    fun getTimeCalendar(time: String) : Calendar {
        val hour = Integer.parseInt(time.split(":".toRegex()).dropLastWhile(String::isEmpty).toTypedArray()[0])
        val minute = Integer.parseInt(time.split(":".toRegex()).dropLastWhile(String::isEmpty).toTypedArray()[1])
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
        }
        /*val now = Calendar.getInstance()
        now.add(Calendar.SECOND, 1)
        if (calendar.before(now)) {
            calendar.add(Calendar.DATE, 1)
        }*/
        return calendar
    }

    fun getCurrentTime() : Calendar {
        val now = Calendar.getInstance()
        //val time = android.text.format.Time()
        //time.setToNow()
        return now
    }

}