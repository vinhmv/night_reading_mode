package com.vn.accessibility.bluelightfilter.utils

import android.graphics.Color
import android.preference.PreferenceManager
import com.vn.accessibility.bluelightfilter.application.BlueLightFilterApplication

/**
 * Created by sev_user on 6/7/2017.
 */
data class Utils(
        var opacity: Int = Utils.DEFAULT_OPACITY,
        var dimLevel: Int = Utils.DEFAULT_DIM_LEVEL,
        var tempColor: Int = Utils.DEFAULT_COLOR) {

    private fun floatToColorBits(color: Float): Int = (color * 255.0f).toInt()
    private fun colorBitsToFloat(bits: Int): Float = bits.toFloat() / 255.0f

    val filterColor: Int
        get() {
            val rgbColor = rgbFromColor(tempColor)
            val opacityColor = Color.argb(floatToColorBits(opacity.toFloat() / 100.0f),
                    Color.red(rgbColor),
                    Color.green(rgbColor),
                    Color.blue(rgbColor))
            val dimColor = Color.argb(floatToColorBits(screenDim.toFloat() / 100.0f), 0, 0, 0)
            return addColors(dimColor, opacityColor)
        }

    private fun addColors(color1: Int, color2: Int): Int {
        var alpha1 = colorBitsToFloat(Color.alpha(color1))
        var alpha2 = colorBitsToFloat(Color.alpha(color2))
        val red1 = colorBitsToFloat(Color.red(color1))
        val red2 = colorBitsToFloat(Color.red(color2))
        val green1 = colorBitsToFloat(Color.green(color1))
        val green2 = colorBitsToFloat(Color.green(color2))
        val blue1 = colorBitsToFloat(Color.blue(color1))
        val blue2 = colorBitsToFloat(Color.blue(color2))

        // See: http://stackoverflow.com/a/10782314

        // Alpha changed to allow more control
        val fAlpha = alpha2 * INTENSITY_MAX_ALPHA + (DIM_MAX_ALPHA - alpha2 * INTENSITY_MAX_ALPHA) * alpha1
        alpha1 *= ALPHA_ADD_MULTIPLIER
        alpha2 *= ALPHA_ADD_MULTIPLIER

        val alpha = floatToColorBits(fAlpha)
        val red = floatToColorBits((red1 * alpha1 + red2 * alpha2 * (1.0f - alpha1)) / fAlpha)
        val green = floatToColorBits((green1 * alpha1 + green2 * alpha2 * (1.0f - alpha1)) / fAlpha)
        val blue = floatToColorBits((blue1 * alpha1 + blue2 * alpha2 * (1.0f - alpha1)) / fAlpha)

        return Color.argb(alpha, red, green, blue)
    }

    companion object {

        fun getColorTemperature(color: Int): Int = 500 + color * 30

        fun rgbFromColor(color: Int): Int { // convert temperature (K) to Color(rgb)
            val colorTemperature = getColorTemperature(color)
            val alpha = 255 // alpha is managed separately

            // After: http://www.tannerhelland.com/4435/convert-temperature-rgb-algorithm-code/
            val temp = colorTemperature.toDouble() / 100.0f

            var red: Double
            if (temp <= 66)
                red = 255.0
            else {
                red = temp - 60
                red = 329.698727446 * Math.pow(red, -0.1332047592)
                if (red < 0) red = 0.0
                if (red > 255) red = 255.0
            }

            var green: Double
            if (temp <= 66) {
                green = temp
                green = 99.4708025861 * Math.log(green) - 161.1195681661
                if (green < 0) green = 0.0
                if (green > 255) green = 255.0
            } else {
                green = temp - 60
                green = 288.1221695283 * Math.pow(green, -0.0755148492)
                if (green < 0) green = 0.0
                if (green > 255) green = 255.0
            }

            var blue: Double
            if (temp >= 66)
                blue = 255.0
            else {
                if (temp < 19)
                    blue = 0.0
                else {
                    blue = temp - 10
                    blue = 138.5177312231 * Math.log(blue) - 305.0447927307
                    if (blue < 0) blue = 0.0
                    if (blue > 255) blue = 255.0
                }
            }

            return Color.argb(alpha, red.toInt(), green.toInt(), blue.toInt())
        }


        //All shared preferences
        val KEY_STATE_OF_FILTER_PREF: String = "key_state_of_filter_pref"
        val KEY_TEMP_COLOR_PREF: String = "key_temp_color"
        val KEY_OPACITY_PREF: String = "key_opacity_pref"
        val KEY_SCREEN_DIM_PREF: String = "key_screen_dim_pref"
        val KEY_ENABLED_SCHEDULE_PREF: String = "key_enabled_schedule_pref"
        val KEY_TIME_START_PREF: String = "key_time_start_pref"
        val KEY_TIME_END_PREF: String = "key_time_end_pref"

        const val DEFAULT_COLOR = 18
        const val DEFAULT_DIM_LEVEL = 0
        const val DEFAULT_OPACITY = 0
        const val DIM_MAX_ALPHA = 0.9f
        private const val INTENSITY_MAX_ALPHA = 0.75f
        private const val ALPHA_ADD_MULTIPLIER = 0.75f

        //var context = BlueLightFilterApplication.app
        private val prefs = PreferenceManager.getDefaultSharedPreferences(BlueLightFilterApplication.context)

        private fun getBooleanPref(key: String, defValue: Boolean): Boolean {
            return prefs.getBoolean(key, defValue)
        }

        private fun putBooleanPref(key: String, newValue: Boolean) {
            prefs.edit().putBoolean(key, newValue).apply()
        }

        private fun getIntPref(key: String, defValue: Int): Int {
            return prefs.getInt(key, defValue)
        }

        private fun putIntPref(key: String, newValue: Int) {
            prefs.edit().putInt(key, newValue).apply()
        }

        private fun getStringPref(key: String, defValue: String): String {
            return prefs.getString(key, defValue)
        }

        private fun putStringPref(key: String, newValue: String) {
            prefs.edit().putString(key, newValue).apply()
        }

        var isOnFilter: Boolean
            get() = getBooleanPref(KEY_STATE_OF_FILTER_PREF, false)
            set(value) = putBooleanPref(KEY_STATE_OF_FILTER_PREF, value)

        var isEnabledSchedule: Boolean
            get() = getBooleanPref(KEY_ENABLED_SCHEDULE_PREF, false)
            set(value) = putBooleanPref(KEY_ENABLED_SCHEDULE_PREF, value)

        var tempColor: Int
            get() = getIntPref(KEY_TEMP_COLOR_PREF, DEFAULT_COLOR)
            set(tc) = putIntPref(KEY_TEMP_COLOR_PREF, tc)

        var opacity: Int
            get() = getIntPref(KEY_OPACITY_PREF, DEFAULT_OPACITY)
            set(o) = putIntPref(KEY_OPACITY_PREF, o)

        var screenDim: Int
            get() = getIntPref(KEY_SCREEN_DIM_PREF, DEFAULT_DIM_LEVEL)
            set(d) = putIntPref(KEY_SCREEN_DIM_PREF, d)

        var timeStart: String
            get() = getStringPref(KEY_TIME_START_PREF, "22:00");
            set(t) = putStringPref(KEY_TIME_START_PREF, t)

        var timeEnd: String
            get() = getStringPref(KEY_TIME_END_PREF, "07:00");
            set(t) = putStringPref(KEY_TIME_END_PREF, t)
    }

}
