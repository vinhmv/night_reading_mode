package com.vn.accessibility.bluelightfilter.view

import android.animation.*
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.content.res.Resources
import android.graphics.PixelFormat
import android.os.Build
import android.preference.PreferenceManager
import android.util.DisplayMetrics
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.WindowManager
import com.vn.accessibility.bluelightfilter.application.BlueLightFilterApplication
import com.vn.accessibility.bluelightfilter.service.ScreenFilterService
import com.vn.accessibility.bluelightfilter.utils.Utils

/**
 * Created by sev_user on 6/9/2017.
 */

private const val DEFAULT_NAV_BAR_HEIGHT_DP = 48
private const val DEFAULT_STATUS_BAR_HEIGHT_DP = 25

class WindowViewManager (service: ScreenFilterService) {



    private class ProfileEvalutor : TypeEvaluator<Utils>{
        val intEvaluator = IntEvaluator()
        val argbEvaluator = ArgbEvaluator()
        override fun evaluate(fraction: Float, startValue: Utils, endValue: Utils) = endValue.copy(
                opacity = intEvaluator.evaluate(fraction, startValue.opacity, endValue.opacity),
                dimLevel = intEvaluator.evaluate(fraction, startValue.dimLevel, endValue.dimLevel),
                tempColor = argbEvaluator.evaluate(fraction, startValue.tempColor, endValue.tempColor) as Int

        )
    }
    private val mSharedPrefs: SharedPreferences
        get() = PreferenceManager.getDefaultSharedPreferences(BlueLightFilterApplication.context)

    private val mResources: Resources = service.resources
    private var mStatusBarHeight = -1
    private var mNavigationBarHeight = -1


    val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    val sfView = ScreenFilterView(service)

    fun addView() {
        mAnimator.removeAllListeners()
        setCustomProfile()
        setProfile(sfView.profile)
        if (Utils.isOnFilter){
            updateView()
        } else{
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                wm.addView(sfView, layoutParamsO)
            } else {
                wm.addView(sfView, layoutParams)
            }
            Utils.isOnFilter = true
            var editor = mSharedPrefs!!.edit()
            editor.putBoolean(Utils.KEY_STATE_OF_FILTER_PREF, true)
            editor.apply()
        }
    }

    fun removeView(){
        mAnimator.removeAllListeners()
        mAnimator.addListener(object : Animator.AnimatorListener{
            override fun onAnimationRepeat(animation: Animator) {
            }

            override fun onAnimationCancel(animation: Animator) {
            }

            override fun onAnimationStart(animation: Animator) {
            }

            override fun onAnimationEnd(animation: Animator) {
                    Log.e("vinh", "onAnimationEnd isOnFilter")
                    wm.removeView(sfView)
                    //Utils.isOnFilter = false
            }

        })
        setProfile(Utils(opacity =  0, tempColor = 0, dimLevel =  0))
    }

    fun setCustomProfile(){
        sfView.profile = Utils( opacity =  Utils.opacity,
                                tempColor = Utils.tempColor,
                                dimLevel =  Utils.screenDim
        )
    }

    fun updateView(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            wm.updateViewLayout(sfView, layoutParamsO)
        } else {
            wm.updateViewLayout(sfView, layoutParams)
        }
    }

    val mAnimator = ValueAnimator.ofObject(ProfileEvalutor(), sfView.profile).apply {
        addUpdateListener { animation: ValueAnimator? ->
            sfView.profile = animation!!.animatedValue as Utils
            if (Utils.isOnFilter){
                updateView()
            }
        }
    }

    fun setProfile(profile:Utils) = mAnimator.run {
        setObjectValues(sfView.profile, profile)
        start()
    }

    val layoutParams: WindowManager.LayoutParams
        get() = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                screenHeight,
                0,
                -statusBarHeightPx,
                WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        or WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR
                        or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

    val layoutParamsO: WindowManager.LayoutParams
        get() = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                screenHeight,
                0,
                -statusBarHeightPx,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        or WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR
                        or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }


    val screenHeight: Int
        get() {
            val display = wm.defaultDisplay
            val dm = DisplayMetrics()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                display.getRealMetrics(dm)
            }
            return if (inPortrait) {
                dm.heightPixels + statusBarHeightPx + navigationBarHeightPx
            } else {
                dm.heightPixels + statusBarHeightPx
            }
        }

    val statusBarHeightPx: Int
        get() {
            if (mStatusBarHeight == -1) {
                val statusBarHeightId = mResources.getIdentifier("status_bar_height", "dimen", "android")

                if (statusBarHeightId > 0) {
                    mStatusBarHeight = mResources.getDimensionPixelSize(statusBarHeightId)
                    //Log.i("Found Status Bar Height: " + mStatusBarHeight)
                } else {
                    mStatusBarHeight = dpToPx(DEFAULT_STATUS_BAR_HEIGHT_DP)
                    //Log.i("Using default Status Bar Height: " + mStatusBarHeight)
                }
            }

            return mStatusBarHeight
        }

    val navigationBarHeightPx: Int
        get() {
            if (mNavigationBarHeight == -1) {
                val navBarHeightId = mResources.getIdentifier("navigation_bar_height", "dimen", "android")

                if (navBarHeightId > 0) {
                    mNavigationBarHeight = mResources.getDimensionPixelSize(navBarHeightId)
                    //Log.i("Found Navigation Bar Height: " + mNavigationBarHeight)
                } else {
                    mNavigationBarHeight = dpToPx(DEFAULT_NAV_BAR_HEIGHT_DP)
                    //Log.i("Using default Navigation Bar Height: " + mNavigationBarHeight)
                }
            }

            return mNavigationBarHeight
        }

    private fun dpToPx(dp: Int): Int {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                dp.toFloat(), mResources.displayMetrics).toInt()
    }

    private val inPortrait: Boolean
        get() = mResources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT


}