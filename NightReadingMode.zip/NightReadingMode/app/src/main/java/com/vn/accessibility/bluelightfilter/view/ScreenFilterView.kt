package com.vn.accessibility.bluelightfilter.view

import android.content.Context
import android.graphics.Canvas
import android.view.View
import com.vn.accessibility.bluelightfilter.utils.Utils

/**
 * Created by sev_user on 6/8/2017.
 */
class ScreenFilterView(context: Context) : View (context){
    //companion object{
        var profile : Utils = Utils()
           /* set(value) {
                field = value
            }*/
    //}
    override fun onDraw(canvas: Canvas) = canvas.drawColor(profile.filterColor)

}