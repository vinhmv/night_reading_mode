package com.vn.accessibility.bluelightfilter.activity

import android.annotation.TargetApi
import android.app.NotificationManager
import android.content.*
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.preference.PreferenceManager
import android.provider.Settings
import android.support.v4.view.GravityCompat
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.SeekBar
import android.widget.TimePicker
import com.google.android.gms.ads.*
import com.google.android.gms.analytics.Tracker
import com.vn.accessibility.bluelightfilter.R
import com.vn.accessibility.bluelightfilter.application.BlueLightFilterApplication
import com.vn.accessibility.bluelightfilter.service.ScreenFilterService
import com.vn.accessibility.bluelightfilter.utils.Utils
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.app_bar_main.*
import kotlinx.android.synthetic.main.content_main.*
import com.google.android.gms.analytics.HitBuilders



class MainActivity : AppCompatActivity(), /*NavigationView.OnNavigationItemSelectedListener,*/ View.OnClickListener, SharedPreferences.OnSharedPreferenceChangeListener {

    val TAG = "MainActivity"
    val REQUEST_CODE = 10101
    protected var mProgress: Int = 0
    val DEFAULT_VALUE: Int = Utils.DEFAULT_OPACITY // val is same final in Java: val = final var
    lateinit var tempColorInt: IntArray
    private var mTracker: Tracker ?= null

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        //TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    private val mSharedPrefs: SharedPreferences
        get() = PreferenceManager.getDefaultSharedPreferences(BlueLightFilterApplication.context)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)
        context = this
        var application: BlueLightFilterApplication = getApplication() as BlueLightFilterApplication
        mTracker = application.getDefaultTracker()

        //supportActionBar?.setLogo(R.drawable.icon_app)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)){
            showPermissionDialog()
        }
        tempColorInt = resources.getIntArray(R.array.temperature_color_int)
        updateSeekBarValues()
        updateCircleBackground()
        updateTimeSchedule()
        Log.e("vinh", "mSharedPrefs.getBoolean(Utils.KEY_STATE_OF_FILTER_PREF, false) : " +
                mSharedPrefs.getBoolean(Utils.KEY_STATE_OF_FILTER_PREF, false))
        if (mSharedPrefs.getBoolean(Utils.KEY_STATE_OF_FILTER_PREF, false)) {
            switch_color_filter.isChecked = true
        } else {
            switch_color_filter.isChecked = false
        }
        if (mSharedPrefs.getBoolean(Utils.KEY_ENABLED_SCHEDULE_PREF, false)) {
            schedule_switch.isChecked = true
            //val intent = Intent(this, ScreenFilterService::class.java) as Intent
            //startService(intent)
        }
        setDisableSchedules()

        //nav_view.setNavigationItemSelectedListener(this)
        switch_color_filter.setOnClickListener(this)
        schedule_switch.setOnClickListener(this)
        time_start.setOnClickListener(this)
        time_end.setOnClickListener(this)
        night_image.setOnClickListener(this)
        candle_image.setOnClickListener(this)
        low_brightness_image.setOnClickListener(this)
        incandescent_image.setOnClickListener(this)
        fluorescent_image.setOnClickListener(this)
        fluorescent_image.setColorFilter(Color.parseColor("#FF9900"))
        MobileAds.initialize(this, getString(R.string.admob_app_id))
        addAds(this, adView);
        addExpressAds(adView2)

        opacity_seekbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                onSetInitialValue(true, DEFAULT_VALUE, progress)
                opacity_seekbar.progress = progress
                opacity_rate.text = progress.toString() + " %"
                var editor = mSharedPrefs.edit()
                editor.putInt(Utils.KEY_OPACITY_PREF, progress)
                editor.putBoolean(Utils.KEY_STATE_OF_FILTER_PREF, true)
                editor.apply()
                val intent = Intent(this@MainActivity, ScreenFilterService::class.java) as Intent
                startService(intent)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {

            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                if (!switch_color_filter.isChecked) {
                    val intent = Intent(this@MainActivity, ScreenFilterService::class.java) as Intent
                    stopService(intent)
                } else {
                    restartService()
                }
            }

        })

        screen_dim_seekbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                Log.e("vinh", "setOnSeekBarChangeListener")
                screen_dim_seekbar.progress = progress
                screen_dim_rate.text = progress.toString() + " %"
                var editor = mSharedPrefs.edit()
                editor.putInt(Utils.KEY_SCREEN_DIM_PREF, progress)
                editor.putBoolean(Utils.KEY_STATE_OF_FILTER_PREF, true)
                editor.apply()
                //var mamager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                //mamager.cancel(1)
                val intent = Intent(this@MainActivity, ScreenFilterService::class.java) as Intent
                startService(intent)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {

            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                if (!switch_color_filter.isChecked) {
                    val intent = Intent(this@MainActivity, ScreenFilterService::class.java) as Intent
                    stopService(intent)
                } else {
                    restartService()
                }
            }

        })
    }

    override fun onResume() {
        super.onResume()
        if (!mSharedPrefs.getBoolean(Utils.KEY_STATE_OF_FILTER_PREF, false)) {
            switch_color_filter.isChecked = false
        } else {
            switch_color_filter.isChecked = true
        }
        Log.i(TAG, "Setting screen name: " + "MainActivity");
        mTracker?.setScreenName("Image~" + "MainActivity");
        mTracker?.send(HitBuilders.ScreenViewBuilder().build())
        mTracker?.send(HitBuilders.EventBuilder()
                .setCategory("Action")
                .setAction("Share")
                .build())
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.switch_color_filter -> {
                addFullAds(this, 0);
                handleScreenFilter()
            }
            R.id.schedule_switch -> {
                setDisableSchedules()
            }
            R.id.time_start -> {
                showDialogTimeStart()
            }
            R.id.time_end -> {
                showDialogTimeEnd()
            }
            R.id.night_image -> {
                temperature.text = "3200K"
                setTempColorValue(0)
                resetCircleBackground()
                night_image.background = resources.getDrawable(R.drawable.circle_dark)
                restartService()
            }
            R.id.candle_image -> {
                temperature.text = "1800K"
                setTempColorValue(1)
                resetCircleBackground()
                candle_image.background = resources.getDrawable(R.drawable.circle_dark)
                restartService()
            }
            R.id.low_brightness_image -> {
                temperature.text = "2000K"
                setTempColorValue(2)
                resetCircleBackground()
                low_brightness_image.background = resources.getDrawable(R.drawable.circle_dark)
                restartService()
            }
            R.id.incandescent_image -> {
                temperature.text = "2700K"
                setTempColorValue(3)
                resetCircleBackground()
                incandescent_image.background = resources.getDrawable(R.drawable.circle_dark)
                restartService()
            }
            R.id.fluorescent_image -> {
                temperature.text = "3400K"
                setTempColorValue(4)
                resetCircleBackground()
                fluorescent_image.background = resources.getDrawable(R.drawable.circle_dark)
                restartService()
            }

            else -> Log.e("vinh", "Unknown click event.")

        }
    }

    fun showPermissionDialog(){
        val builder = android.app.AlertDialog.Builder(this)
        builder.setTitle(R.string.dialog_title_permission_overlay)
        builder.setMessage(R.string.dialog_message_permission_overlay)
        builder.setPositiveButton("OK", { dialogInterface: DialogInterface, i: Int ->
            checkDrawOverlayPermission()
        })
        builder.setCancelable(false)
        builder.show()
    }


    fun setTempColorValue(index: Int) {
        var editor = mSharedPrefs.edit()
        editor.putInt(Utils.KEY_TEMP_COLOR_PREF, tempColorInt!![index])
        editor.apply()
    }

    fun getTempColorValue(): Int {
        return mSharedPrefs!!.getInt(Utils.KEY_TEMP_COLOR_PREF, Utils.DEFAULT_COLOR)
    }

    fun isSelectedTempColor(index: Int): Boolean {
        return (getTempColorValue() == tempColorInt.get(index))
    }

    fun updateCircleBackground() {
        if (isSelectedTempColor(0)) {
            night_image.background = resources.getDrawable(R.drawable.circle_dark)
            temperature.text = "3200K"
        } else if (isSelectedTempColor(1)) {
            candle_image.background = resources.getDrawable(R.drawable.circle_dark)
            temperature.text = "1800K"
        } else if (isSelectedTempColor(2)) {
            low_brightness_image.background = resources.getDrawable(R.drawable.circle_dark)
            temperature.text = "2000K"
        } else if (isSelectedTempColor(3)) {
            incandescent_image.background = resources.getDrawable(R.drawable.circle_dark)
            temperature.text = "2700K"
        } else if (isSelectedTempColor(4)) {
            fluorescent_image.background = resources.getDrawable(R.drawable.circle_dark)
            temperature.text = "3400K"
        }
    }

    fun resetCircleBackground() {
        night_image.background = resources.getDrawable(R.drawable.circle_white)
        candle_image.background = resources.getDrawable(R.drawable.circle_white)
        low_brightness_image.background = resources.getDrawable(R.drawable.circle_white)
        incandescent_image.background = resources.getDrawable(R.drawable.circle_white)
        fluorescent_image.background = resources.getDrawable(R.drawable.circle_white)
    }


    fun restartService() {
        if (switch_color_filter.isChecked) {
            val intent = Intent(this@MainActivity, ScreenFilterService::class.java) as Intent
            stopService(intent)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        }
    }

    fun updateTimeSchedule(){
        var timeStart = mSharedPrefs.getString(Utils.KEY_TIME_START_PREF, "22:00")
        var hourStart = Integer.parseInt(timeStart.split(":".toRegex()).dropLastWhile(String::isEmpty).toTypedArray()[0])
        if (hourStart < 12){
            time_start.text =  "ON " + timeStart + " AM"
        } else {
            time_start.text =  "ON " + timeStart + " PM"
        }

        var timeEnd = mSharedPrefs.getString(Utils.KEY_TIME_END_PREF, "07:00")
        var hourEnd = Integer.parseInt(timeEnd.split(":".toRegex()).dropLastWhile(String::isEmpty).toTypedArray()[0])
        if (hourEnd < 12){
            time_end.text =  "OFF " + timeEnd + " AM"
        } else {
            time_end.text =  "OFF " + timeEnd + " PM"
        }
    }



    fun showDialogTimeStart() {
        val builder = android.app.AlertDialog.Builder(this)
        var v : View = layoutInflater.inflate(R.layout.time_picker_start_dialog, null)
        //var timeStart = mSharedPrefs.getString(Utils.KEY_TIME_START_PREF, "22:00")
        //var hourStart = Integer.parseInt(timeStart.split(":".toRegex()).dropLastWhile(String::isEmpty).toTypedArray()[0])
        //timePicker_from?.hour = hourStart;
        builder.setView(v)
                .setPositiveButton("OK", { dialogInterface: DialogInterface, i: Int ->
                     var timePicker_from = v.findViewById<TimePicker>(R.id.timePicker_from) as TimePicker
                     timePicker_from.setIs24HourView(false)
                     var timeStart = (if (timePicker_from.currentHour < 10) "0" else "") + timePicker_from.currentHour.toString() +
                             ":" +(if (timePicker_from.currentMinute < 10) "0" else "") + timePicker_from.currentMinute.toString()
                     var editor = mSharedPrefs.edit()
                     editor.putString(Utils.KEY_TIME_START_PREF, timeStart)
                     editor.apply()
                     updateTimeSchedule()
                     var intent = Intent()
                     intent.setAction("com.vn.accessibility.bluelightfilter.START_SCHEDULE")
                     context.sendBroadcast(intent)
                })
                .setNegativeButton("CANCEL", { dialogInterface: DialogInterface, i: Int ->

                })
                .show()
    }

    fun showDialogTimeEnd() {
        val builder = android.app.AlertDialog.Builder(this)
        var v : View = layoutInflater.inflate(R.layout.time_picker_start_dialog, null)
        builder.setView(v)
                .setPositiveButton("OK", { dialogInterface: DialogInterface, i: Int ->
                    var timePicker_to = v.findViewById<TimePicker>(R.id.timePicker_from) as TimePicker
                    timePicker_to.setIs24HourView(false)
                    var timeEnd = (if (timePicker_to.currentHour < 10) "0" else "") + timePicker_to.currentHour.toString() +
                            ":" +(if (timePicker_to.currentMinute < 10) "0" else "") + timePicker_to.currentMinute.toString()
                    var editor = mSharedPrefs.edit()
                    editor.putString(Utils.KEY_TIME_END_PREF, timeEnd)
                    editor.apply()
                    updateTimeSchedule()
                    var intent = Intent()
                    intent.setAction("com.vn.accessibility.bluelightfilter.END_SCHEDULE")
                    context.sendBroadcast(intent)
                })
                .setNegativeButton("CANCEL", { dialogInterface: DialogInterface, i: Int ->

                })
                .show()
    }

    fun checkDrawOverlayPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }
        if (!Settings.canDrawOverlays(context)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + packageName))
            startActivityForResult(intent, REQUEST_CODE)
            return false
        } else {
            return true
        }

    }

    fun updateSeekBarValues() {
        opacity_seekbar.setProgress(mSharedPrefs.getInt(Utils.KEY_OPACITY_PREF, Utils.DEFAULT_OPACITY))
        opacity_rate.setText(mSharedPrefs.getInt(Utils.KEY_OPACITY_PREF, Utils.DEFAULT_OPACITY).toString() + "%")

        screen_dim_seekbar.setProgress(mSharedPrefs.getInt(Utils.KEY_SCREEN_DIM_PREF, Utils.DEFAULT_DIM_LEVEL))
        screen_dim_rate.setText(mSharedPrefs.getInt(Utils.KEY_SCREEN_DIM_PREF, Utils.DEFAULT_DIM_LEVEL).toString() + "%")
    }

    fun handleScreenFilter() {
        //showPermissionDialog()
        val intent = Intent(this@MainActivity, ScreenFilterService::class.java) as Intent
        if (switch_color_filter.isChecked && checkDrawOverlayPermission()) {
            Log.e("vinh", "checked : true")
            var editor = mSharedPrefs.edit()
            editor.putBoolean(Utils.KEY_STATE_OF_FILTER_PREF, true)
            editor.apply()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        } else {
            Log.e("vinh", "checked : false")
            var editor = mSharedPrefs.edit()
            editor.putBoolean(Utils.KEY_STATE_OF_FILTER_PREF, false)
            editor.apply()
            stopService(intent)
        }
    }

    fun setDisableSchedules() {
        image_schedules.setColorFilter(Color.parseColor("#ABABAB"))
        if (schedule_switch.isChecked) {
            Log.e("vinh", "isChecked")
            var editor = mSharedPrefs.edit()
            editor.putBoolean(Utils.KEY_ENABLED_SCHEDULE_PREF, true)
            editor.apply()
            image_schedules.setColorFilter(Color.parseColor("#000000"))
            time_start.isClickable = true
            time_start.setTextColor(Color.parseColor("#008000"))
            time_end.isClickable = true
            time_end.setTextColor(Color.parseColor("#FF4081"))

        } else {
            var editor = mSharedPrefs.edit()
            editor.putBoolean(Utils.KEY_ENABLED_SCHEDULE_PREF, false)
            editor.apply()
            image_schedules.setColorFilter(Color.parseColor("#ABABAB"))
            time_start.isClickable = false
            time_start.setTextColor(Color.parseColor("#ABABAB"))
            time_end.isClickable = false
            time_end.setTextColor(Color.parseColor("#ABABAB"))
        }
    }

    fun onSetInitialValue(restorePersistedValue: Boolean, defaultValue: Any?, progress: Int) {
        if (restorePersistedValue) {
            //mProgress = getPersistedInt(DEFAULT_VALUE)
        } else {
            mProgress = (defaultValue as Int?) ?: DEFAULT_VALUE
            //persistInt(mProgress)
            var editor = mSharedPrefs!!.edit()
            editor.putInt(Utils.KEY_OPACITY_PREF, progress)
            editor.apply()
        }
    }

    @TargetApi(Build.VERSION_CODES.M)
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        //super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE) {
            if (Settings.canDrawOverlays(this)) {

            }
        }
    }

    override fun onBackPressed() {
        if (drawer_layout.isDrawerOpen(GravityCompat.START)) {
            drawer_layout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }

    //AdView
    lateinit var mInterstitialAd : InterstitialAd;
    fun addAds(context: Context, adView: AdView) {
        //banner ads
        var adRequest = AdRequest.Builder().build()
        adView?.loadAd(adRequest)

    }

    fun addFullAds(context: Context, delay: Int ) {
        mInterstitialAd = InterstitialAd(context)
        mInterstitialAd.adUnitId = context.getString(R.string.full);
        mInterstitialAd.loadAd(AdRequest.Builder().build())
        mInterstitialAd.adListener = object : AdListener(){
            override fun onAdLoaded() {
                super.onAdLoaded();
                var delayAds = Handler()
                delayAds.postDelayed(Runnable {
                    //kotlin.run {
                    showInterstitial()
                    //}
                }, delay.toLong())

            }
        }
    }

        fun showInterstitial() {
        mInterstitialAd?.show();
    }

    fun addExpressAds(expressAdView: NativeExpressAdView) {
        var adRequest = AdRequest.Builder().build()
        expressAdView?.loadAd(adRequest)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item!!.itemId) {
            R.id.rate_app -> {
                rateThisApp(this)
                return true
            }

        }
            return super.onOptionsItemSelected(item)
    }

    private fun rateThisApp(context: Context) {
        val uri = Uri.parse("market://details?id=" + context.packageName)
        val goToMarket = Intent(Intent.ACTION_VIEW, uri)
        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY or
                //Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
        try {
            startActivity(goToMarket)
        } catch (e: ActivityNotFoundException) {
            startActivity(Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/details?id=" + context.packageName)))
        }

    }

    override fun onDestroy() {
        //mSharedPrefs.unregisterOnSharedPreferenceChangeListener(this)
        super.onDestroy()
    }

    companion object {
        lateinit var context: MainActivity
    }
}

