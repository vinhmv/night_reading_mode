package com.vn.accessibility.bluelightfilter.service

import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.IBinder
import android.preference.PreferenceManager
import android.util.Log
import com.vn.accessibility.bluelightfilter.application.BlueLightFilterApplication
import com.vn.accessibility.bluelightfilter.utils.Utils
import com.vn.accessibility.bluelightfilter.view.WindowViewManager
import android.content.Context.NOTIFICATION_SERVICE
import android.content.Context
import android.graphics.Color
import android.support.v4.app.NotificationCompat
import com.vn.accessibility.bluelightfilter.R
import com.vn.accessibility.bluelightfilter.receiver.StopServiceReceiver

/**
 * Created by sev_user on 6/8/2017.
 */

class ScreenFilterService : Service() {
    private lateinit var mWindowViewManager: WindowViewManager

    private val mSharedPrefs: SharedPreferences
        get() = PreferenceManager.getDefaultSharedPreferences(BlueLightFilterApplication.context)

    override fun onCreate() {
        Log.e("vinh", "service onCreate")
        super.onCreate()

        val CHANNEL_ID = "my_channel_01"
        val turnOffIntentBroadcast = Intent(this, StopServiceReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(this, 0, turnOffIntentBroadcast, PendingIntent.FLAG_UPDATE_CURRENT)
        var notificationId = System.currentTimeMillis() % 10000

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            var mamager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(CHANNEL_ID,"Night Reading Mode", NotificationManager.IMPORTANCE_HIGH)
            //channel.lockscreenVisibility = Notification.VISIBILITY_PRIVATE
            channel.lightColor = Color.BLUE
            //channel.importance = NotificationManager.IMPORTANCE_NONE
            mamager.createNotificationChannel(channel)
            val notification = NotificationCompat.Builder(this, CHANNEL_ID).setOngoing(true)
                    .setContentTitle("Night Reading Mode is turning ON.")
                    .addAction(android.R.drawable.arrow_up_float, "Turn OFF", pendingIntent)
                    .setAutoCancel(false)
                    .setSmallIcon(R.drawable.ic_launcher)
                    .setCategory(Notification.CATEGORY_SERVICE)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setContentText("Tap here to turn OFF now")
                    .setContentIntent(pendingIntent)
                    .build()
            //mamager.notify(1, notification)
            startForeground(1, notification)
        } else {
            val notification = NotificationCompat.Builder(this).setOngoing(true)
                    .setContentTitle("Night Reading Mode is turning ON.")
                    .addAction(android.R.drawable.arrow_up_float, "Turn OFF", pendingIntent)
                    .setAutoCancel(false)
                    .setSmallIcon(R.drawable.ic_launcher)
                    .setCategory(Notification.CATEGORY_SERVICE)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setContentText("Tap here to turn OFF now")
                    .setContentIntent(pendingIntent)
                    .build()
            //mamager.notify(notificationId.toInt(), notification)
            startForeground(1, notification)
        }

        Utils.isOnFilter = false
        mWindowViewManager = WindowViewManager(this)
        mWindowViewManager.addView()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.e("vinh", "onStartCommand")
        return Service.START_STICKY
    }

    override fun onDestroy() {
        Log.e("vinh", "service onDestroy")
        mWindowViewManager.removeView()
        Utils.isOnFilter = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? = null //prevent binding

    companion object {
        lateinit var context: ScreenFilterService
    }


}